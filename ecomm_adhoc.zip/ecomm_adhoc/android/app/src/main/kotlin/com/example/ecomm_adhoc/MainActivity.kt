package com.example.ecomm_adhoc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
